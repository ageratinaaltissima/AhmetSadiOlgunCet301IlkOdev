import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

void main() {
  runApp(MyFirstApp());
}
class MyFirstApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
         appBar: AppBar(
           backgroundColor: Colors.black12,
           title: Text("My Info",
           style: TextStyle(
             fontFamily: 'BebasNeue',
           ),
           ),
           leading: Icon(Icons.contact_mail, size: 50.0,),
         ),
          body: Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            crossAxisAlignment: CrossAxisAlignment.stretch,

            children: [
             CircleAvatar(
               radius: 120,
               backgroundImage: AssetImage('images/AhmetSaidOlgun.jpg',)
             ),

             Row(
               children: [
                new Text("Name:",
                 style: new TextStyle(
                   fontFamily: 'BebasNeue',
                   fontSize: 35.0,
                   color: Colors.black12
                 ),
                 ),

               ],
             ),
              Row(
                children: [
                 new Text("Ahmet Said Olgun",
                      style: new TextStyle(
                          fontFamily: 'AnticSlab',
                          fontSize: 35.0,
                          color: Colors.amberAccent
                      ),
                  ),
                ],
              ),
              Row(
                children: [
                  Container(
                    color: Colors.red,
                    padding: EdgeInsets.all(5.0),
                    child: Icon(
                      Icons.mail,
                      size: 50,
                    ),
                  ),
                  SizedBox(
                    width: 10.0,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: new Text('aolgun98@gmail.com',
                      style: new TextStyle(
                          fontFamily: 'AnticSlab',
                          fontSize: 20.0,
                          color: Colors.black
                      ),
                    ),
                  )
                ],
              ),
              Row(
                children: [
                  Container(
                    color: Colors.blue,
                    padding: EdgeInsets.all(5.0),
                    child: Icon(
                      Icons.phone,
                      size: 50,
                    ),
                  ),
                  SizedBox(
                    width: 10.0,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10.0),
                    child: new Text('05442241326',
                      style: new TextStyle(
                          fontFamily: 'BebasNeue',
                          fontSize: 20.0,
                          color: Colors.black
                      ),
                    ),
                  )
                ],
              )
            ]
          )
        )
    );
  }
}


